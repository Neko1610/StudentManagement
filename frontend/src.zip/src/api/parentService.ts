import client from './client';
import { Parent, Student, Tuition, Fund, Teacher, Request } from '../types';

export const parentService = {
  getProfile: (id: string): Promise<Parent> => {
    return client.get(`/parents/${id}`).then((res) => res.data);
  },

  updateProfile: (id: string, data: Partial<Parent>): Promise<Parent> => {
    return client.put(`/parents/${id}`, data).then((res) => res.data);
  },

  getChildren: (parentId: string): Promise<Student[]> => {
    return client.get(`/students/parent/${parentId}`).then((res) => res.data);
  },

  getTuition: (studentId: string): Promise<Tuition[]> => {
    return client.get(`/tuition/student/${studentId}`).then((res) => res.data);
  },

  getFunds: (classId: string): Promise<Fund[]> => {
    return client.get(`/fund/class/${classId}`).then((res) => res.data);
  },

  getTeachers: (classId: string): Promise<Teacher[]> => {
    return client.get(`/teachers/class/${classId}`).then((res) => res.data);
  },

  submitRequest: (data: any): Promise<Request> => {
    return client.post('/requests', data).then((res) => res.data);
  },
};
