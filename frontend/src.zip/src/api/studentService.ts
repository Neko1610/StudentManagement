import client from './client';
import { Student, Score, Schedule, Assignment, Submission, Exam } from '../types';

export const studentService = {
  getProfile: (id: string): Promise<Student> => {
    return client.get(`/students/${id}`).then((res) => res.data);
  },

  updateProfile: (id: string, data: Partial<Student>): Promise<Student> => {
    return client.put(`/students/${id}`, data).then((res) => res.data);
  },

  getScores: (studentId: string): Promise<Score[]> => {
    return client.get(`/scores/student/${studentId}`).then((res) => res.data);
  },

  exportScores: (studentId: string): Promise<any> => {
    return client
      .get(`/scores/export/${studentId}`, {
        responseType: 'blob',
      })
      .then((res) => res.data);
  },

  getSchedule: (studentId: string): Promise<Schedule[]> => {
    return client.get(`/schedules/student/${studentId}`).then((res) => res.data);
  },

  getAssignments: (studentId: string): Promise<Assignment[]> => {
    return client.get(`/assignments/student/${studentId}`).then((res) => res.data);
  },

  submitAssignment: (data: any): Promise<Submission> => {
    return client.post('/submissions', data).then((res) => res.data);
  },

  getExams: (studentId: string): Promise<Exam[]> => {
    return client.get(`/exams/student/${studentId}`).then((res) => res.data);
  },
};
