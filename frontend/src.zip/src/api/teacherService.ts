import client from './client';
import { Teacher, Clazz, Student, Attendance, Schedule } from '../types';

// 🔥 convert snake_case → camelCase
const mapSchedule = (s: any): Schedule => ({
  id: s.id,
  dayOfWeek: s.dayOfWeek,
  period: s.period,
  className: s.className,
  subjectName: s.subjectName,
  room: s.room
});

export const teacherService = {
  // PROFILE
  getProfile: async (email: string): Promise<Teacher> => {
    const res = await client.get(`/teachers/email/${email}`);
    return res.data;
  },

  updateProfile: async (id: string, data: Partial<Teacher>): Promise<Teacher> => {
    const res = await client.put(`/teachers/${id}`, data);
    return res.data;
  },

  // CLASSES
 getClasses: async (email: string): Promise<Clazz[]> => {
  console.log("CALL getClasses EMAIL:", email); // 🔥
  const res = await client.get(`/classes/teacher/email/${email}`);
  console.log("CLASSES RES:", res.data); // 🔥
  return res.data || [];
},

  getStudentsByClass: async (classId: string): Promise<Student[]> => {
    const res = await client.get(`/students/class/${classId}`);
    return res.data || [];
  },

  getAttendance: async (classId: string): Promise<Attendance[]> => {
    const res = await client.get(`/attendance/class/${classId}`);
    return res.data || [];
  },

  markAttendance: async (data: any): Promise<Attendance> => {
    const res = await client.post('/attendance', data);
    return res.data;
  },

  // 🔥 SCHEDULE FIX CHUẨN
  getSchedule: async (email: string): Promise<Schedule[]> => {
    const res = await client.get(`/schedules/teacher/email/${email}`);
    return (res.data || []).map(mapSchedule);
  },

  // 🔥 FIX TODAY (lọc frontend)
  getTodaySchedule: async (email: string): Promise<Schedule[]> => {
    const res = await client.get(`/schedules/teacher/email/${email}`);

    const today = new Date()
      .toLocaleDateString('en-US', { weekday: 'long' })
      .toUpperCase();

    return (res.data || [])
      .map(mapSchedule)
      .filter((s: Schedule) => s.dayOfWeek === today);
  },
};