import { Card, List, Table, Button, Modal, Form, Input, Select, message, Spin, Empty } from 'antd';
import { useEffect, useState } from 'react';
import { parentService } from '../../api/parentService';
import { auth } from '../../utils/auth';
import { Teacher, Student } from '../../types';

export default function ParentContacts() {
  const user = auth.getUser();
  const [children, setChildren] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      const data = await parentService.getChildren(user?.id || '');
      setChildren(data);
      if (data.length > 0) {
        loadTeachers(data[0].classId || '');
      }
    } catch (error) {
      message.error('Failed to load children');
    } finally {
      setLoading(false);
    }
  };

  const loadTeachers = async (classId: string) => {
    try {
      setLoading(true);
      const data = await parentService.getTeachers(classId);
      setTeachers(data);
    } catch (error) {
      message.error('Failed to load teachers');
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (values: any) => {
    try {
      setLoading(true);
      // Call API to send message
      message.success('Message sent successfully');
      setModalVisible(false);
      form.resetFields();
    } catch (error) {
      message.error('Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Spin spinning={loading}>
      <Card title="Teachers">
        {teachers.length === 0 ? (
          <Empty description="No teachers" />
        ) : (
          <List
            dataSource={teachers}
            renderItem={(teacher) => (
              <List.Item>
                <List.Item.Meta
                  title={teacher.fullName}
                  description={
                    <>
                      <p>Email: {teacher.email}</p>
                      <p>Phone: {teacher.phone || 'N/A'}</p>
                      <p>Specialization: {teacher.specialization || 'N/A'}</p>
                    </>
                  }
                />
                <Button type="primary" onClick={() => setModalVisible(true)}>
                  Contact
                </Button>
              </List.Item>
            )}
          />
        )}
      </Card>

      <Modal
        title="Send Message to Teacher"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        onOk={() => form.submit()}
      >
        <Form form={form} layout="vertical" onFinish={handleSendMessage}>
          <Form.Item label="Teacher" name="teacherId">
            <Select placeholder="Select teacher" options={teachers.map((t) => ({ label: t.fullName, value: t.id }))} />
          </Form.Item>

          <Form.Item label="Subject" name="subject">
            <Input placeholder="Message subject" />
          </Form.Item>

          <Form.Item label="Message" name="message">
            <Input.TextArea placeholder="Type your message" rows={4} />
          </Form.Item>
        </Form>
      </Modal>
    </Spin>
  );
}
