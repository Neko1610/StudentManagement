import { Card, Form, Button, Input, message, Spin } from 'antd';
import { useState, useEffect } from 'react';
import { parentService } from '../../api/parentService';
import { Parent } from '../../types';
import { auth } from '../../utils/auth';

export default function ParentProfile() {
  const user = auth.getUser();
  
  const [profile, setProfile] = useState<Parent | null>(null);
  const [loading, setLoading] = useState(true);
  const [form] = Form.useForm();

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const data = await parentService.getProfile(user?.id || '');
      setProfile(data);
      form.setFieldsValue(data);
    } catch (error) {
      message.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async (values: any) => {
    try {
      await parentService.updateProfile(user?.id || '', values);
      message.success('Profile updated successfully');
    } catch (error) {
      message.error('Failed to update profile');
    }
  };

  return (
    <Spin spinning={loading}>
      <Card title="My Profile">
        <Form form={form} layout="vertical" onFinish={handleSaveProfile}>
          <Form.Item label="Full Name" name="fullName">
            <Input />
          </Form.Item>

          <Form.Item label="Email" name="email">
            <Input type="email" />
          </Form.Item>

          <Form.Item label="Phone" name="phone">
            <Input />
          </Form.Item>

          <Form.Item label="Address" name="address">
            <Input />
          </Form.Item>

          <Form.Item label="Occupation" name="occupation">
            <Input />
          </Form.Item>

          <Form.Item label="Relationship" name="relationship">
            <Input placeholder="e.g., Father, Mother, Guardian" />
          </Form.Item>

          <Button type="primary" htmlType="submit">
            Save Profile
          </Button>
        </Form>
      </Card>
    </Spin>
  );
}
