import { Card, List, Empty, Spin, Button, Space, message } from 'antd';
import { useEffect, useState } from 'react';
import { parentService } from '../../api/parentService';
import { auth } from '../../utils/auth';
import { Student } from '../../types';

export default function ParentStudents() {
  const user = auth.getUser();
  const [children, setChildren] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      const data = await parentService.getChildren(user?.id || '');
      setChildren(data);
    } catch (error) {
      message.error('Failed to load children');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Spin spinning={loading}>
      <Card title="My Children">
        {children.length === 0 ? (
          <Empty description="No children" />
        ) : (
          <List
            dataSource={children}
            renderItem={(child) => (
              <List.Item>
                <List.Item.Meta
                  title={child.fullName}
                  description={
                    <>
                      <p>Email: {child.email}</p>
                      <p>Class: {child.classId || 'N/A'}</p>
                      <p>Phone: {child.phone || 'N/A'}</p>
                    </>
                  }
                />
                <Space>
                  <Button type="primary">View Scores</Button>
                  <Button>View Attendance</Button>
                  <Button>View Assignments</Button>
                </Space>
              </List.Item>
            )}
          />
        )}
      </Card>
    </Spin>
  );
}
