import { Card, List, Table, Empty, Spin, Tabs, message } from 'antd';
import { DollarOutlined } from '@ant-design/icons';
import { useEffect, useState } from 'react';
import { parentService } from '../../api/parentService';
import { auth } from '../../utils/auth';
import { Tuition, Fund, Student } from '../../types';

export default function ParentTuition() {
  const user = auth.getUser();
  const [children, setChildren] = useState<Student[]>([]);
  const [tuitions, setTuitions] = useState<Tuition[]>([]);
  const [funds, setFunds] = useState<Fund[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedChild, setSelectedChild] = useState<string>('');

  useEffect(() => {
    loadChildren();
  }, []);

  const loadChildren = async () => {
    try {
      const data = await parentService.getChildren(user?.id || '');
      setChildren(data);
      if (data.length > 0) {
        loadTuition(data[0].id);
      }
    } catch (error) {
      message.error('Failed to load children');
    } finally {
      setLoading(false);
    }
  };

  const loadTuition = async (studentId: string) => {
    try {
      setLoading(true);
      setSelectedChild(studentId);
      const [tuitionData, fundData] = await Promise.all([
        parentService.getTuition(studentId),
        parentService.getFunds(children.find((c) => c.id === studentId)?.classId || ''),
      ]);

      setTuitions(tuitionData);
      setFunds(fundData);
    } catch (error) {
      message.error('Failed to load tuition information');
    } finally {
      setLoading(false);
    }
  };

  const tuitionColumns = [
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount: number) => `$${amount.toFixed(2)}`,
    },
    {
      title: 'Due Date',
      dataIndex: 'dueDate',
      key: 'dueDate',
      render: (date: string) => new Date(date).toLocaleDateString(),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <span style={{ color: status === 'PAID' ? 'green' : 'red' }}>
          {status}
        </span>
      ),
    },
  ];

  return (
    <Spin spinning={loading}>
      <Tabs
        items={[
          {
            key: 'tuition',
            label: 'Tuition Fees',
            children: (
              <Card>
                <div style={{ marginBottom: '16px' }}>
                  <label>Select Child: </label>
                  <select
                    value={selectedChild}
                    onChange={(e) => loadTuition(e.target.value)}
                    style={{ marginLeft: '8px', padding: '4px 8px', borderRadius: '4px' }}
                  >
                    {children.map((child) => (
                      <option key={child.id} value={child.id}>
                        {child.fullName}
                      </option>
                    ))}
                  </select>
                </div>

                {tuitions.length === 0 ? (
                  <Empty description="No tuition records" />
                ) : (
                  <Table
                    dataSource={tuitions}
                    columns={tuitionColumns}
                    rowKey="id"
                    pagination={{ pageSize: 10 }}
                  />
                )}
              </Card>
            ),
          },
          {
            key: 'fund',
            label: 'Class Fund',
            children: (
              <Card>
                {funds.length === 0 ? (
                  <Empty description="No fund records" />
                ) : (
                  <List
                    dataSource={funds}
                    renderItem={(fund) => (
                      <List.Item>
                        <List.Item.Meta
                          avatar={<DollarOutlined />}
                          title={fund.name}
                          description={`Amount: $${fund.amount.toFixed(2)}`}
                        />
                      </List.Item>
                    )}
                  />
                )}
              </Card>
            ),
          },
        ]}
      />
    </Spin>
  );
}
