import { Card, List, Button, Modal, Form, Upload, message, Spin, Empty, Input } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import { useState, useEffect } from 'react';
import { studentService } from '../../api/studentService';
import { Assignment } from '../../types';
import { auth } from '../../utils/auth';

export default function StudentAssignments() {
  const user = auth.getUser();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<string>('');
  const [form] = Form.useForm();

  useEffect(() => {
    loadAssignments();
  }, []);

  const loadAssignments = async () => {
    try {
      const data = await studentService.getAssignments(user?.id || '');
      setAssignments(data);
    } catch (error) {
      message.error('Failed to load assignments');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values: any) => {
    try {
      setLoading(true);
      await studentService.submitAssignment({
        assignmentId: selectedAssignment,
        studentId: user?.id,
        ...values,
      });
      message.success('Assignment submitted successfully');
      setModalVisible(false);
      form.resetFields();
      loadAssignments();
    } catch (error) {
      message.error('Failed to submit assignment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Spin spinning={loading}>
      <Card title="My Assignments">
        {assignments.length === 0 ? (
          <Empty description="No assignments" />
        ) : (
          <List
            dataSource={assignments}
            renderItem={(assignment) => (
              <List.Item>
                <List.Item.Meta
                  title={assignment.title}
                  description={
                    <>
                      <p>{assignment.description}</p>
                      <small>Due: {new Date(assignment.dueDate).toLocaleDateString()}</small>
                    </>
                  }
                />
                <Button
                  type="primary"
                  onClick={() => {
                    setSelectedAssignment(assignment.id);
                    setModalVisible(true);
                  }}
                >
                  Submit
                </Button>
              </List.Item>
            )}
          />
        )}
      </Card>

      <Modal
        title="Submit Assignment"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        onOk={() => form.submit()}
      >
        <Form form={form} layout="vertical" onFinish={handleSubmit}>
          <Form.Item label="File" name="file">
            <Upload.Dragger>
              <p className="ant-upload-drag-icon">
                <InboxOutlined />
              </p>
              <p className="ant-upload-text">Click or drag file to upload</p>
            </Upload.Dragger>
          </Form.Item>

          <Form.Item label="Notes" name="notes">
            <Input.TextArea placeholder="Any additional notes" rows={3} />
          </Form.Item>
        </Form>
      </Modal>
    </Spin>
  );
}
