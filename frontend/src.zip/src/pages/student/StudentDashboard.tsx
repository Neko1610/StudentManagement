import { Card, Row, Col, Statistic, Spin, Empty, List } from 'antd';
import { FileTextOutlined, BellOutlined, CalendarOutlined } from '@ant-design/icons';
import { useEffect, useState } from 'react';
import { studentService } from '../../api/studentService';
import { commonService } from '../../api/commonService';
import { auth } from '../../utils/auth';
import { Assignment, Notification } from '../../types';

export default function StudentDashboard() {
  const user = auth.getUser();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [assignmentsData, notificationsData] = await Promise.all([
        studentService.getAssignments(user?.id || ''),
        commonService.getNotifications(),
      ]);

      setAssignments(assignmentsData);
      setNotifications(notificationsData.slice(0, 5));
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Spin spinning={loading}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <h1>Welcome, {user?.fullName}</h1>

        <Row gutter={16}>
          <Col xs={24} sm={12} lg={6}>
            <Card>
              <Statistic
                title="Pending Assignments"
                value={assignments.filter((a) => new Date(a.dueDate) > new Date()).length}
                prefix={<FileTextOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card>
              <Statistic
                title="Unread Notifications"
                value={notifications.filter((n) => !n.isRead).length}
                prefix={<BellOutlined />}
              />
            </Card>
          </Col>
        </Row>

        <Row gutter={16}>
          <Col xs={24} lg={12}>
            <Card title="My Assignments">
              {assignments.length === 0 ? (
                <Empty description="No assignments" />
              ) : (
                <List
                  dataSource={assignments}
                  renderItem={(assignment) => (
                    <List.Item>
                      <List.Item.Meta
                        title={assignment.title}
                        description={`Due: ${new Date(assignment.dueDate).toLocaleDateString()}`}
                      />
                    </List.Item>
                  )}
                />
              )}
            </Card>
          </Col>

          <Col xs={24} lg={12}>
            <Card title="Recent Notifications">
              {notifications.length === 0 ? (
                <Empty description="No notifications" />
              ) : (
                <List
                  dataSource={notifications}
                  renderItem={(notification) => (
                    <List.Item>
                      <List.Item.Meta
                        title={notification.title}
                        description={notification.content}
                      />
                    </List.Item>
                  )}
                />
              )}
            </Card>
          </Col>
        </Row>
      </div>
    </Spin>
  );
}
