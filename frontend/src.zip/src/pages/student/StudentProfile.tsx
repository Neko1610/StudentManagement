import { Card, Form, Button, Input, message, Spin } from 'antd';
import { useState, useEffect } from 'react';
import { studentService } from '../../api/studentService';
import { Student } from '../../types';
import { auth } from '../../utils/auth';

export default function StudentProfile() {
  const user = auth.getUser();
  const [profile, setProfile] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);
  const [form] = Form.useForm();

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const data = await studentService.getProfile(user?.id || '');
      setProfile(data);
      form.setFieldsValue(data);
    } catch (error) {
      message.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async (values: any) => {
    try {
      await studentService.updateProfile(user?.id || '', values);
      message.success('Profile updated successfully');
    } catch (error) {
      message.error('Failed to update profile');
    }
  };

  return (
    <Spin spinning={loading}>
      <Card title="My Profile">
        <Form form={form} layout="vertical" onFinish={handleSaveProfile}>
          <Form.Item label="Full Name" name="fullName">
            <Input />
          </Form.Item>

          <Form.Item label="Email" name="email">
            <Input type="email" />
          </Form.Item>

          <Form.Item label="Phone" name="phone">
            <Input />
          </Form.Item>

          <Form.Item label="Date of Birth" name="dateOfBirth">
            <Input type="date" />
          </Form.Item>

          <Form.Item label="Gender" name="gender">
            <select style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #d9d9d9' }}>
              <option value="">Select</option>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
            </select>
          </Form.Item>

          <Form.Item label="Address" name="address">
            <Input />
          </Form.Item>

          <Button type="primary" htmlType="submit">
            Save Profile
          </Button>
        </Form>
      </Card>
    </Spin>
  );
}
