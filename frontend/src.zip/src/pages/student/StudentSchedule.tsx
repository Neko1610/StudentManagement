import { Card, Table, Spin, Empty, message } from 'antd';
import { useEffect, useState } from 'react';
import { studentService } from '../../api/studentService';
import { Schedule } from '../../types';
import { auth } from '../../utils/auth';

export default function StudentSchedule() {
  const user = auth.getUser();
  const [schedule, setSchedule] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSchedule();
  }, []);

  const loadSchedule = async () => {
    try {
      const data = await studentService.getSchedule(user?.id || '');
      setSchedule(data);
    } catch (error) {
      message.error('Failed to load schedule');
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      title: 'Subject',
      dataIndex: 'subjectId',
      key: 'subjectId',
    },
    {
      title: 'Day',
      dataIndex: 'dayOfWeek',
      key: 'dayOfWeek',
    },
    {
      title: 'Time',
      key: 'time',
      render: (_: any, record: Schedule) => `${record.startTime} - ${record.endTime}`,
    },
    {
      title: 'Room',
      dataIndex: 'room',
      key: 'room',
    },
  ];

  return (
    <Spin spinning={loading}>
      <Card title="My Schedule">
        {schedule.length === 0 ? (
          <Empty description="No schedule" />
        ) : (
          <Table dataSource={schedule} columns={columns} rowKey="id" pagination={{ pageSize: 10 }} />
        )}
      </Card>
    </Spin>
  );
}
