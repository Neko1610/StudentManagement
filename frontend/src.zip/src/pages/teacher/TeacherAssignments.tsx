import {
  Card, Table, Button, Modal, Form, InputNumber,
  Select, message, Spin
} from 'antd';
import { useState, useEffect } from 'react';
import { teacherService } from '../../api/teacherService';
import { auth } from '../../utils/auth';

export default function TeacherAssignments() {
  const user = auth.getUser();

  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [form] = Form.useForm();

  const [classes, setClasses] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [editing, setEditing] = useState<any>(null);

  // 🔥 LOAD CLASSES
  useEffect(() => {
    loadClasses();
  }, []);

  const loadClasses = async () => {
    try {
      const res = await teacherService.getClasses(user?.email || '');
      setClasses(res);
    } catch {
      message.error('Failed to load classes');
    }
  };

  // 🔥 LOAD STUDENTS
  const loadStudents = async (classId: string) => {
    try {
      setLoading(true);
      const res = await teacherService.getStudentsByClass(classId);

      // mock thêm score nếu chưa có
      const mapped = res.map((s: any) => ({
        ...s,
        studentName: s.fullName,
        subject: 'Math',
        score: s.score || null
      }));

      setStudents(mapped);
    } finally {
      setLoading(false);
    }
  };

  // 🔥 SELECT CLASS
  const handleSelectClass = (classId: string) => {
    setSelectedClass(classId);
    loadStudents(classId);
  };

  // 🔥 EDIT
  const handleEdit = (record: any) => {
    setEditing(record);
    setModalVisible(true);

    form.setFieldsValue({
      score: record.score,
      coefficient: 1
    });
  };

  // 🔥 SAVE
  const handleSave = async () => {
    try {
      const values = await form.validateFields();

      const updated = students.map(s =>
        s.id === editing.id
          ? { ...s, score: values.score }
          : s
      );

      setStudents(updated);

      setModalVisible(false);
      message.success('Saved!');
    } catch {
      message.error('Failed');
    }
  };

  // 🔥 EXPORT
  const handleExport = () => {
    console.log("EXPORT DATA:", students);
    message.success('Exported to Excel (mock)');
  };

  const columns = [
    {
      title: 'Student',
      dataIndex: 'studentName',
    },
    {
      title: 'Subject',
      dataIndex: 'subject',
    },
    {
      title: 'Score',
      dataIndex: 'score',
      render: (score: number) => score !== null ? score.toFixed(2) : '-',
    },
    {
      title: 'Actions',
      render: (_: any, record: any) => (
        <Button size="small" type="primary" onClick={() => handleEdit(record)}>
          Edit
        </Button>
      ),
    },
  ];

  return (
    <Spin spinning={loading}>
      <Card
        title="Class Scores"
        extra={
          <Button onClick={handleExport}>
            Export Excel
          </Button>
        }
      >
        {/* 🔥 SELECT CLASS */}
        <Select
          placeholder="Select Class"
          style={{ width: 200, marginBottom: 16 }}
          onChange={handleSelectClass}
          options={classes.map(c => ({
            label: c.name,
            value: c.id
          }))}
        />

        <Table
          columns={columns}
          dataSource={students}
          rowKey="id"
          pagination={{ pageSize: 10 }}
        />
      </Card>

      {/* 🔥 MODAL */}
      <Modal
        title="Edit Score"
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        onOk={handleSave}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            label="Score"
            name="score"
            rules={[{ required: true }]}
          >
            <InputNumber min={0} max={10} step={0.5} style={{ width: '100%' }} />
          </Form.Item>

          <Form.Item label="Coefficient" name="coefficient">
            <InputNumber min={1} style={{ width: '100%' }} />
          </Form.Item>
        </Form>
      </Modal>
    </Spin>
  );
}