export default function TeacherScores() {
  return <div>Teacher Scores Page</div>;
}